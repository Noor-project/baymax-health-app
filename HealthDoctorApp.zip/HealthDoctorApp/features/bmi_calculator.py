import streamlit as st
from datetime import datetime
from logic.database import get_db
from logic.auth import require_login
from logic.error_handler import handle_error
from graphs.health_charts import show_bmi_graph
import os

@require_login
def show_bmi_calculator():
    """Main BMI calculator interface with visual enhancements"""
    try:
        st.markdown("""
            <div style="background-color:#FDEBD0;padding:25px;border-radius:10px;margin-bottom:20px;">
                <h2 style="color:#2874A6;font-size:32px;">📊 <b>BMI & Health Tracker</b></h2>
                <p style="font-size:18px;color:#555;">Track your Body Mass Index (BMI) and monitor your health journey in style.</p>
            </div>
        """, unsafe_allow_html=True)

        # Input Form
        with st.form("bmi_form"):
            col1, col2 = st.columns(2)

            with col1:
                st.markdown("<h4 style='font-size:22px;'>⚖️ Weight (kg)</h4>", unsafe_allow_html=True)
                weight = st.number_input("", min_value=1.0, max_value=500.0, step=0.1, key="weight", format="%.1f")

            with col2:
                st.markdown("<h4 style='font-size:22px;'>📏 Height</h4>", unsafe_allow_html=True)
                height_unit = st.radio("Select unit", ["Meters", "Feet"], key="height_unit", horizontal=True)

                if height_unit == "Meters":
                    height_m = st.number_input("Height (m)", min_value=0.3, max_value=2.5, step=0.01, key="height_m", format="%.2f")
                else:
                    feet = st.number_input("Feet", min_value=1, max_value=8, step=1, key="height_ft")
                    inches = st.number_input("Inches", min_value=0, max_value=11, step=1, key="height_in")
                    height_m = convert_feet_inches_to_meters(feet, inches)

            st.markdown("""
                <style>
                    div.stButton > button {
                        background-color: #3498DB;
                        color: white;
                        font-size: 18px;
                        font-weight: bold;
                        border-radius: 10px;
                        padding: 10px 20px;
                        transition: 0.3s;
                    }
                    div.stButton > button:hover {
                        background-color: #2E86C1;
                    }
                </style>
            """, unsafe_allow_html=True)

            if st.form_submit_button("🧮 Calculate BMI"):
                if weight <= 0 or height_m <= 0:
                    st.error("❌ Values must be positive.")
                else:
                    bmi = calculate_bmi(weight, height_m)
                    save_record(weight, height_m, bmi)
                    display_results(bmi)

        # Button to Show Graph
        st.markdown("<br>", unsafe_allow_html=True)
        graph_button = st.button("📈 Show My BMI Graph")
        if graph_button:
            show_bmi_graph()

        # Button to Export BMI Records to TXT
        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("💾 Export BMI Records to TXT"):
            user_id = st.session_state.user['id']
            export_bmi_records_to_txt(user_id)

    except Exception as e:
        handle_error(e)

def convert_feet_inches_to_meters(feet: int, inches: int) -> float:
    """Convert feet and inches to meters"""
    total_inches = feet * 12 + inches
    return round(total_inches * 0.0254, 4)

def calculate_bmi(weight: float, height: float) -> float:
    """Calculate BMI using height in meters"""
    return round(weight / (height ** 2), 1)

def save_record(weight: float, height: float, bmi: float) -> None:
    """Save BMI data to the database"""
    try:
        with get_db() as conn:
            conn.execute(
                "INSERT INTO health_metrics (user_id, weight, height, bmi) VALUES (?, ?, ?, ?)",
                (st.session_state.user['id'], weight, height, bmi)
            )
            conn.commit()
        st.toast("✅ Data saved successfully!")
    except Exception as e:
        st.error(f"❌ Failed to save: {str(e)}")
        raise

def display_results(bmi: float) -> None:
    """Display BMI result with color-coded category"""
    st.markdown(f"""
        <div style="background-color:#D6EAF8;padding:20px;border-radius:10px;margin-top:20px;">
            <h3 style="color:#154360;font-size:28px;">📐 Your BMI is: <span style="color:#2E86C1;">{bmi:.1f}</span></h3>
        </div>
    """, unsafe_allow_html=True)

    if bmi < 18.5:
        st.markdown("""
            <div style="background-color:#FCF3CF;padding:15px;border-radius:10px;margin-top:10px;">
                <strong style="font-size:20px;">⚠️ Underweight</strong><br>🏋️‍♂️ Improve your nutrition and health routine.
            </div>
        """, unsafe_allow_html=True)

    elif 18.5 <= bmi < 25:
        st.markdown("""
            <div style="background-color:#D5F5E3;padding:15px;border-radius:10px;margin-top:10px;">
                <strong style="font-size:20px;">✅ Healthy Weight</strong><br>🌟 Great job! Maintain your lifestyle.
            </div>
        """, unsafe_allow_html=True)

    elif 25 <= bmi < 30:
        st.markdown("""
            <div style="background-color:#FADBD8;padding:15px;border-radius:10px;margin-top:10px;">
                <strong style="font-size:20px;">⚠️ Overweight</strong><br>🍏 Start light exercises and eat healthy.
            </div>
        """, unsafe_allow_html=True)

    else:
        st.markdown("""
            <div style="background-color:#F5B7B1;padding:15px;border-radius:10px;margin-top:10px;">
                <strong style="font-size:20px;">🚨 Obese</strong><br>🩺 Please consult a healthcare provider soon.
            </div>
        """, unsafe_allow_html=True)

def export_bmi_records_to_txt(user_id: int, filename: str = "bmi_records.txt"):
    """Fetch BMI records from DB and save to a text file"""
    try:
        with get_db() as conn:
            records = conn.execute(
                "SELECT weight, height, bmi, timestamp FROM health_metrics WHERE user_id = ? ORDER BY timestamp",
                (user_id,)
            ).fetchall()

        if not records:
            st.warning("No BMI records found to export.")
            return

        with open(filename, "w") as f:
            f.write("Weight (kg)\tHeight (m)\tBMI\tTimestamp\n")
            for weight, height, bmi, timestamp in records:
                f.write(f"{weight}\t{height}\t{bmi}\t{timestamp}\n")

        st.success(f"Exported {len(records)} BMI records to '{os.path.abspath(filename)}'")

    except Exception as e:
        st.error(f"Error exporting records: {e}")
