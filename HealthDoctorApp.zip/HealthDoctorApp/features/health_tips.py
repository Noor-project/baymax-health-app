import streamlit as st
import requests
import socket

# --- Check Internet Connection ---
def is_connected():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True
    except OSError:
        return False

# --- Fetch Health Topics ---
def fetch_health_topics():
    try:
        response = requests.get("https://health.gov/myhealthfinder/api/v3/topicsearch.json", timeout=5)
        response.raise_for_status()
        data = response.json()
        return data.get("Result", {}).get("Resources", {}).get("Resource", [])
    except Exception:
        return None

# --- Fetch Topic Details ---
def fetch_topic_details(topic_id):
    try:
        url = f"https://health.gov/myhealthfinder/api/v3/topicsearch.json?TopicId={topic_id}"
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        data = response.json()
        return data.get("Result", {}).get("Resources", {}).get("Resource", [])[0]
    except Exception:
        return None

# --- Mock Data for Offline Mode ---
MOCK_TOPICS = {
    "Healthy Eating": "Eat a variety of fruits and vegetables every day. Limit sugar and salt intake.",
    "Physical Activity": "Aim for at least 30 minutes of moderate exercise most days of the week.",
    "Mental Wellness": "Practice mindfulness and relaxation techniques to reduce stress."
}

# --- MAIN DISPLAY FUNCTION ---
def show_health_tips():
    st.markdown("<h1 style='text-align:center; color:#4CAF50;'>🌿 Smart Health Tips Panel</h1>", unsafe_allow_html=True)
    st.markdown("<hr style='border:1px solid #4CAF50;'>", unsafe_allow_html=True)

    # Inspiring Quote
    st.markdown("""
        <div style='background-color:#e0f7fa; padding:15px; border-left:5px solid #26a69a; border-radius:8px;'>
            <h4 style='color:#00695c;'>💬 "Take care of your body. It's the only place you have to live." – Jim Rohn</h4>
        </div>
    """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # --- Mode Toggle Buttons ---
    st.markdown("### <span style='color:#333;'>🔀 Choose Mode</span>", unsafe_allow_html=True)
    
    # Custom Button Styling
    st.markdown("""
    <style>
        div[data-testid="stButton"] > button[kind="primary"] {
            background: #4CAF50 !important;
            border: 2px solid #4CAF50 !important;
            color: white !important;
            font-weight: bold !important;
        }
        div[data-testid="stButton"] > button[kind="secondary"] {
            background: #f8f9fa !important;
            border: 2px solid #4CAF50 !important;
            color: #4CAF50 !important;
        }
        div[data-testid="stButton"] > button {
            width: 100% !important;
            padding: 10px !important;
            transition: all 0.3s ease !important;
        }
        div[data-testid="stButton"] > button:hover {
            transform: scale(1.02);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
    </style>
    """, unsafe_allow_html=True)

    col1, col2 = st.columns(2)
    current_mode = st.session_state.get("mode", "online")

    with col1:
        if st.button("🌐 Online Mode", 
                    help="Get real-time health tips", 
                    key="online_btn",
                    type="primary" if current_mode == "online" else "secondary"):
            st.session_state.mode = "online"

    with col2:
        if st.button("📴 Offline Mode", 
                    help="View predefined offline tips", 
                    key="offline_btn",
                    type="primary" if current_mode == "offline" else "secondary"):
            st.session_state.mode = "offline"

    st.markdown("<hr>", unsafe_allow_html=True)

    # Determine current mode
    if st.session_state.get("mode", "online") == "offline":
        st.markdown("<h3 style='color:#ff6f00;'>📴 Offline Mode: Choose a Health Topic</h3>", unsafe_allow_html=True)
        col1, col2, col3 = st.columns(3)
        selected_mock_topic = None

        with col1:
            if st.button("🥗 Healthy Eating"):
                selected_mock_topic = "Healthy Eating"
        with col2:
            if st.button("🏃‍♂️ Physical Activity"):
                selected_mock_topic = "Physical Activity"
        with col3:
            if st.button("🧘 Mental Wellness"):
                selected_mock_topic = "Mental Wellness"

        if selected_mock_topic:
            st.markdown(f"<h4 style='color:#008080;'>🩺 {selected_mock_topic}</h4>", unsafe_allow_html=True)
            st.markdown(
                f"<div style='padding:15px; background-color:#f0f8ff; border-radius:10px; font-size:16px;'>{MOCK_TOPICS[selected_mock_topic]}</div>",
                unsafe_allow_html=True
            )
        return

    # --- Online Mode Functionality ---
    if not is_connected():
        st.error("❌ No Internet Connection – Cannot fetch health tips.")
        return

    topics = fetch_health_topics()
    if not topics:
        st.warning("⚠️ Could not load health tips from the API. Please try again later.")
        return

    st.markdown("""
        <div style="padding: 10px; background-color: #fce4ec; border-radius: 8px;">
            <h4 style='color:#ad1457;'>🗂️ Choose a <b>Health Category</b></h4>
        </div>
    """, unsafe_allow_html=True)

    topic_dict = {topic["Title"]: topic["Id"] for topic in topics}
    selected_topic = st.selectbox("📋 Select a category to view tips:", ["-- Select --"] + list(topic_dict.keys()))

    if selected_topic and selected_topic != "-- Select --":
        topic_id = topic_dict[selected_topic]
        topic_details = fetch_topic_details(topic_id)

        if topic_details:
            st.markdown(f"<h2 style='color:#008080;'>🩺 {topic_details.get('Title', '')}</h2>", unsafe_allow_html=True)
            st.markdown(
                f"<div style='padding:15px; background-color:#e3f2fd; border-radius:10px; font-size:16px;'>{topic_details.get('Sections', {}).get('section', [{}])[0].get('Content', '')}</div>",
                unsafe_allow_html=True
            )
        else:
            st.error("❌ Failed to fetch topic details.")
    else:
        st.markdown("""
            <div style='padding: 10px; margin-top: 10px; background-color:#fff3e0; color:#ef6c00; border-radius:8px; font-weight:bold;'>
                ⏳ Please select a health category to view real-time tips...
            </div>
        """, unsafe_allow_html=True)

    # --- Footer ---
    st.markdown("<br><hr style='border: 1px dashed #ccc;'>", unsafe_allow_html=True)
    st.markdown("<div style='text-align: center; color: gray;'>Made with ❤️ to care for your health</div>", unsafe_allow_html=True)