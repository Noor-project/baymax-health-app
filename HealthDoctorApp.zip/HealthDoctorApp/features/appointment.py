import streamlit as st
import requests
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import os

API_URL = "https://your-hospital-api.example.com"
APPOINTMENTS_FILE = "appointments.txt"

MOCK_DOCTORS = [
    {"id": 1, "name": "Dr. Alice Smith"},
    {"id": 2, "name": "Dr. Bob Johnson"},
    {"id": 3, "name": "Dr. Carol Williams"},
    {"id": 4, "name": "Dr. David Brown"},
    {"id": 5, "name": "Dr. Eva Davis"},
]

APPOINTMENT_TYPES = [
    "General Consultation",
    "Follow-up Visit",
    "Emergency",
    "Routine Check-up",
    "Telemedicine",
]

def fetch_doctors():
    try:
        resp = requests.get(f"{API_URL}/doctors", timeout=3)
        resp.raise_for_status()
        doctors = resp.json()
        st.success("✅ Connected to live hospital API")
        return doctors
    except Exception:
        # Silent fallback, no message
        return MOCK_DOCTORS

def save_appointment_to_txt(patient_name, doctor_name, appointment_date, time_slot, appointment_type):
    record = (
        f"Patient: {patient_name} | Doctor: {doctor_name} | "
        f"Date: {appointment_date} | Time: {time_slot} | Type: {appointment_type}\n"
    )
    with open(APPOINTMENTS_FILE, "a", encoding="utf-8") as f:
        f.write(record)

def load_appointments_from_txt():
    if not os.path.exists(APPOINTMENTS_FILE):
        return []
    with open(APPOINTMENTS_FILE, "r", encoding="utf-8") as f:
        return f.readlines()

def colored_box(text, box_type="info"):
    colors = {
        "info": "#720A32",
        "success": "#D4EDDA",
        "warning": "#FFF3CD",
        "error": "#F8D7DA",
    }
    color = colors.get(box_type, "#6A2A7A")
    st.markdown(
        f"""
        <div style="background-color:{color}; padding: 10px; border-radius: 8px; margin-bottom: 10px;">
            {text}
        </div>
        """,
        unsafe_allow_html=True
    )

def show_appointment():
    st.markdown("<h1 style='color:#003366; font-weight:bold;'>📅 Book Appointment</h1>", unsafe_allow_html=True)

    doctors = fetch_doctors()

    patient_name = st.text_input("Enter your full name", max_chars=50)

    doctor_options = ["Choose Doctor"] + [doc["name"] for doc in doctors]
    selected_doctor_name = st.selectbox(
        "Select Doctor",
        doctor_options,
        index=0,
        help="Click to see the doctor list"
    )

    appointment_date = st.date_input(
        "Select Date",
        min_value=datetime.now().date(),
        max_value=(datetime.now() + timedelta(days=30)).date()
    )

    time_slot = st.selectbox(
        "Select Time Slot",
        ["09:00-10:00", "11:00-12:00", "14:00-15:00", "16:00-17:00"]
    )

    appointment_type = st.selectbox("Appointment Type", APPOINTMENT_TYPES)

    can_book = patient_name.strip() != "" and selected_doctor_name != "Choose Doctor"

    if not can_book:
        colored_box("⚠️ Please enter your name and select a doctor before booking.", "warning")

    if st.button("Confirm Booking", disabled=not can_book):
        if selected_doctor_name == "Choose Doctor":
            colored_box("❌ Selected doctor not found. Please try again.", "error")
            return

        # Save appointment to txt file
        save_appointment_to_txt(patient_name, selected_doctor_name, appointment_date, time_slot, appointment_type)

        colored_box(
            f"✅ Appointment booked successfully!<br>"
            f"<b>Patient:</b> {patient_name}<br>"
            f"<b>Doctor:</b> {selected_doctor_name}<br>"
            f"<b>Date:</b> {appointment_date}<br>"
            f"<b>Time Slot:</b> {time_slot}<br>"
            f"<b>Type:</b> {appointment_type}",
            "success"
        )

    st.markdown("---")
    st.markdown("<h3 style='color:#1e1381;'>Doctors Available</h3>", unsafe_allow_html=True)
    st.write(f"Total Doctors: **{len(doctors)}**")

    # Create mock availability data for visualization
    df = pd.DataFrame({
        "Doctor": [doc["name"] for doc in doctors],
        "Available Slots": np.random.randint(1, 5, size=len(doctors))
    })

    max_slots = df["Available Slots"].max()
    colors = ["#3518b6", "#562a7a", "#B61BA9", "#69149b", "#8616a8"]
    color_map = {i: colors[min(i-1, len(colors)-1)] for i in range(1, max_slots+1)}

    def bar_color_slots(val):
        return f"background-color: {color_map[val]}"

    def bar_color_doctor(val):
        return "background-color: #4A90E2; color: white; font-weight: bold; text-align: center"

    styled_df = df.style \
        .applymap(bar_color_slots, subset=["Available Slots"]) \
        .applymap(bar_color_doctor, subset=["Doctor"]) \
        .set_properties(**{
            'color': 'white',
            'font-weight': 'bold',
            'text-align': 'center'
        }, subset=["Doctor", "Available Slots"])

    st.write(styled_df, unsafe_allow_html=True)

    # Show saved appointments from text file
    st.markdown("---")
    st.markdown("<h3>Saved Appointments (Local Text File)</h3>", unsafe_allow_html=True)
    saved_appointments = load_appointments_from_txt()
    if saved_appointments:
        for idx, appt in enumerate(saved_appointments, 1):
            st.markdown(f"**{idx}.** {appt}")
    else:
        st.info("No saved appointments found in local text file.")


if __name__ == "__main__":
    show_appointment()
