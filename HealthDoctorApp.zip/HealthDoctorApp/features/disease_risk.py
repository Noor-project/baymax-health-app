import streamlit as st
import matplotlib.pyplot as plt
from datetime import datetime

def show_disease_risk():
    st.markdown("""
    <style>
        /* Custom title style */
        .custom-title {
            background-color: #2C3E50;
            color: #00ACC1;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            font-weight: bold;
            font-size: 28px;
        }

        div[data-testid="stCheckbox"] label {
            color: #0F3460 !important;
            font-weight: bold;
            font-size: 16px;
        }

        .checkbox-container {
            margin-top: 20px;
            background-color: #1A252F;
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #00ACC1;
        }
    </style>
    """, unsafe_allow_html=True)

    st.markdown("<div class='custom-title'>🧬 Disease Risk Estimator</div>", unsafe_allow_html=True)

    st.markdown("<div class='checkbox-container'>", unsafe_allow_html=True)
    st.markdown('<div class="checkbox-label">', unsafe_allow_html=True)
    consent = st.checkbox(
        label="I agree to provide my health information for risk estimation",
        key="consent_checkbox"
    )
    st.markdown("</div>", unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)

    if not consent:
        st.info("Please agree to the permission above to proceed.")
        return

    with st.form("risk_form"):
        st.subheader("Lifestyle & Health Factors")

        age = st.slider("Age", 1, 100, 30)
        smoker = st.selectbox(
            "Smoking Status",
            options=["Choose your answer", "Never smoked", "Former smoker", "Current smoker"],
            index=0
        )
        exercise = st.selectbox(
            "Exercise Frequency (per week)",
            options=["Choose your answer", "None", "1-2 days", "3-5 days", "Daily"],
            index=0
        )
        family_history = st.selectbox(
            "Family history of chronic diseases",
            options=["Choose your answer", "No", "Yes"],
            index=0
        )
        bmi = st.slider("Body Mass Index (BMI)", 10.0, 40.0, 22.0, 0.1)
        alcohol = st.selectbox(
            "Alcohol Consumption",
            options=["Choose your answer", "None", "Occasional", "Regular"],
            index=0
        )
        diet = st.selectbox(
            "Diet Quality",
            options=["Choose your answer", "Poor", "Average", "Good"],
            index=0
        )
        stress = st.selectbox(
            "Stress Level",
            options=["Choose your answer", "Low", "Moderate", "High"],
            index=0
        )

        submit = st.form_submit_button("Calculate Risk")

    if submit:
        required_fields = [smoker, exercise, family_history, alcohol, diet, stress]
        if any(field.startswith("Choose your answer") for field in required_fields):
            st.warning("Please select valid answers for all fields.")
            return

        # Risk scoring logic...
        risk_score = 0
        if age >= 65:
            risk_score += 3
        elif age >= 50:
            risk_score += 2
        elif age >= 35:
            risk_score += 1

        smoker_map = {"Never smoked": 0, "Former smoker": 2, "Current smoker": 4}
        exercise_map = {"None": 3, "1-2 days": 2, "3-5 days": 1, "Daily": 0}
        family_history_map = {"No": 0, "Yes": 2}
        alcohol_map = {"None": 0, "Occasional": 1, "Regular": 3}
        diet_map = {"Poor": 3, "Average": 1, "Good": 0}
        stress_map = {"Low": 0, "Moderate": 1, "High": 2}

        risk_score += smoker_map[smoker]
        risk_score += exercise_map[exercise]
        risk_score += family_history_map[family_history]
        risk_score += alcohol_map[alcohol]
        risk_score += diet_map[diet]
        risk_score += stress_map[stress]

        if bmi < 18.5:
            risk_score += 2
        elif bmi > 30:
            risk_score += 3
        elif bmi > 25:
            risk_score += 1

        max_score = 20
        risk_percentage = min(risk_score / max_score, 1.0)

        if risk_score <= 5:
            risk_level = "Low Risk"
            risk_message = "Great job! Keep maintaining your healthy habits."
            st.success(f"**{risk_level}** (Score: {risk_score}/{max_score})\n\n{risk_message}")
        elif 6 <= risk_score <= 12:
            risk_level = "Moderate Risk"
            risk_message = "Consider improving your lifestyle and regular medical check-ups."
            st.warning(f"**{risk_level}** (Score: {risk_score}/{max_score})\n\n{risk_message}")
        else:
            risk_level = "High Risk"
            risk_message = "It's important to consult a healthcare professional soon."
            st.error(f"**{risk_level}** (Score: {risk_score}/{max_score})\n\n{risk_message}")

        # Risk bar chart
        fig, ax = plt.subplots(figsize=(6, 1.5))
        fig.patch.set_facecolor('#2C3E50')
        ax.set_facecolor('#2C3E50')
        color_map = {"Low Risk": "#4CAF50", "Moderate Risk": "#FF9800", "High Risk": "#F44336"}
        ax.barh(["Risk"], [risk_percentage], color=color_map[risk_level])
        ax.set_xlim(0, 1)
        ax.set_xlabel("Risk Level (0 to 100%)", color='white')
        ax.set_yticks([])
        ax.set_xticks([0, 0.25, 0.5, 0.75, 1])
        ax.set_xticklabels(['0%', '25%', '50%', '75%', '100%'])
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.spines['left'].set_visible(False)
        ax.spines['bottom'].set_color('#00ACC1')
        ax.tick_params(axis='x', colors='white')
        st.pyplot(fig)

        with st.expander("See detailed score breakdown"):
            bmi_score = 2 if bmi < 18.5 else 3 if bmi > 30 else 1 if bmi > 25 else 0
            st.markdown(f"- Age: {age} years → Score: {3 if age>=65 else 2 if age>=50 else 1 if age>=35 else 0}")
            st.markdown(f"- Smoking: {smoker} → Score: {smoker_map[smoker]}")
            st.markdown(f"- Exercise: {exercise} → Score: {exercise_map[exercise]}")
            st.markdown(f"- Family history: {family_history} → Score: {family_history_map[family_history]}")
            st.markdown(f"- BMI: {bmi:.1f} → Score: {bmi_score}")
            st.markdown(f"- Alcohol: {alcohol} → Score: {alcohol_map[alcohol]}")
            st.markdown(f"- Diet quality: {diet} → Score: {diet_map[diet]}")
            st.markdown(f"- Stress level: {stress} → Score: {stress_map[stress]}")
            st.markdown(f"**Total Risk Score: {risk_score} / {max_score}**")

        # --- Save results to file ---
        # Compose a CSV line with timestamp, inputs, risk info
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"{timestamp},{age},{smoker},{exercise},{family_history},{bmi:.1f},{alcohol},{diet},{stress},{risk_score},{risk_level}\n"

        try:
            with open("disease_risk_data.txt", "a") as f:
                f.write(line)
            st.info("✅ Your data has been saved successfully.")
        except Exception as e:
            st.error(f"Failed to save data: {e}")

if __name__ == "__main__":
    show_disease_risk()
