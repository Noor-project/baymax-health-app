import streamlit as st
import plotly.express as px
import os
from services.api_connector import fetch_api
from services.pdf_export import generate_pdf

def show_api_data_viewer():
    st.markdown("<h2 style='color:#006699'>🌐 Real Health API & Visualization</h2>", unsafe_allow_html=True)

    st.markdown("""
        <style>
            div.stSelectbox > div[data-testid="stSelectbox"] > div > div {
                background: linear-gradient(90deg, #6a11cb 0%, #2575fc 100%);
                color: white;
                font-weight: bold;
                border-radius: 8px;
                padding: 5px 10px;
            }
            div.stSelectbox > label > div {
                font-weight: bold;
                color: #2575fc;
                margin-bottom: 5px;
            }
            div.stButton > button {
                background-color: #2575fc;
                color: white;
                font-weight: 700;
                border-radius: 8px;
                padding: 10px 24px;
                border: none;
                transition: background-color 0.3s ease;
            }
            div.stButton > button:hover {
                background-color: #6a11cb;
                cursor: pointer;
            }
        </style>
    """, unsafe_allow_html=True)

    endpoint = st.selectbox("Choose API Endpoint", ["global", "pakistan", "india", "usa", "vaccines"])

    # Ensure session state is initialized
    if "api_data" not in st.session_state:
        st.session_state.api_data = None
        st.session_state.last_endpoint = ""

    if st.button("Fetch & Visualize"):
        data = fetch_api(endpoint)
        if "error" in data:
            st.error(data["error"])
            st.session_state.api_data = None
            return

        st.session_state.api_data = data
        st.session_state.last_endpoint = endpoint
        st.success("✅ Live API data loaded successfully!")

    data = st.session_state.get("api_data")
    endpoint = st.session_state.get("last_endpoint")

    if data:
        # COVID Pie Chart
        if endpoint in ["global", "pakistan", "india", "usa"]:
            st.subheader("🧠 COVID-19 Breakdown")
            fig = px.pie(
                names=["Active", "Recovered", "Deaths"],
                values=[data.get("active", 0), data.get("recovered", 0), data.get("deaths", 0)],
                color_discrete_map={"Active": "#ff9800", "Recovered": "#4caf50", "Deaths": "#f44336"},
                title=f"COVID-19 Status: {endpoint.capitalize()}"
            )
            fig.update_traces(pull=[0.05, 0, 0.1], textinfo="label+percent")
            st.plotly_chart(fig, use_container_width=True)

        # Vaccine Bar Chart
        elif endpoint == "vaccines":
            st.subheader("💉 Vaccine Coverage (Top 10 Countries)")
            vaccine_data = data.get("data", {}) if isinstance(data, dict) else None

            if not vaccine_data:
                st.info("⚠️ Live data unavailable. Showing sample vaccine data instead.")
                vaccine_data = {
                    "USA": "200000000", "India": "150000000", "Pakistan": "90000000",
                    "Brazil": "120000000", "UK": "95000000", "Germany": "87000000",
                    "France": "86000000", "Italy": "82000000", "Russia": "80000000", "Canada": "79000000"
                }

            top_countries = sorted(vaccine_data.items(), key=lambda x: int(x[1]), reverse=True)[:10]
            countries = [country for country, _ in top_countries]
            coverage = [int(count) for _, count in top_countries]

            flags = {
                "USA": "🇺🇸", "India": "🇮🇳", "Pakistan": "🇵🇰", "Brazil": "🇧🇷", "Germany": "🇩🇪",
                "UK": "🇬🇧", "France": "🇫🇷", "Italy": "🇮🇹", "Russia": "🇷🇺", "Canada": "🇨🇦"
            }
            labels = [f"{flags.get(c, '')} {c}" for c in countries]

            fig = px.bar(
                x=labels, y=coverage,
                labels={"x": "Country", "y": "Vaccine Doses"},
                title="🌍 Vaccine Distribution by Country (Top 10)",
                color=coverage, color_continuous_scale=px.colors.sequential.Plasma,
            )

            fig.update_traces(marker_line_color='black', marker_line_width=1.5,
                              text=[f"{v:,}" for v in coverage], textposition='outside',
                              hovertemplate='<b>%{x}</b><br>Vaccine Doses: %{y:,}<extra></extra>')
            fig.update_layout(xaxis_tickangle=-45, font=dict(size=13),
                              plot_bgcolor="#f9f9f9", paper_bgcolor="#f9f9f9",
                              coloraxis_colorbar=dict(title="Doses"))
            st.plotly_chart(fig, use_container_width=True)

        # Raw JSON
        st.subheader("📦 Raw JSON Data")
        st.json(data)

        # Export to PDF
        if isinstance(data, dict):
            key_stats = list(data.items())[:5]
        elif isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict):
            key_stats = list(data[0].items())[:5]
        else:
            key_stats = ["Data format not supported"]

        pdf_data = {
            "Diagnosis": f"API Endpoint: {endpoint}\n\nKey Stats: {key_stats}",
            "Medication": "N/A",
            "Dosage": "N/A"
        }

        if st.button("📄 Export API Data to PDF"):
            filepath = generate_pdf(pdf_data)
            if os.path.exists(filepath):
                with open(filepath, "rb") as f:
                    st.download_button(
                        label="📅 Download PDF Report",
                        data=f,
                        file_name=os.path.basename(filepath),
                        mime="application/pdf"
                    )

if __name__ == "__main__":
    show_api_data_viewer()
