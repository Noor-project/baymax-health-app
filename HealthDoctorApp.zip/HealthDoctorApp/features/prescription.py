import streamlit as st
import os
import json
from datetime import datetime

PRESCRIPTIONS_FILE = "prescriptions.txt"

# ---------------- TXT FILE SAVE/LOAD ------------------
def save_prescription_to_txt(user_id, diagnosis, medication, dosage):
    record = (
        f"User: {user_id} | "
        f"Diagnosis: {diagnosis} | "
        f"Medication: {medication} | "
        f"Dosage: {dosage}\n"
    )
    with open(PRESCRIPTIONS_FILE, "a", encoding="utf-8") as f:
        f.write(record)

def load_prescriptions_from_txt():
    if not os.path.exists(PRESCRIPTIONS_FILE):
        return []
    with open(PRESCRIPTIONS_FILE, "r", encoding="utf-8") as f:
        return f.readlines()

# ---------------- DISPLAY FORM ------------------
def show_prescription():
    st.markdown("<h1 style='text-align:center; color:#0DAF94;'>💊 Digital Prescription</h1>", unsafe_allow_html=True)
    st.markdown("<hr>", unsafe_allow_html=True)

    with st.form("prescription_form"):
        diagnosis = st.text_area("Diagnosis")
        medication = st.text_input("Medication")
        dosage = st.text_input("Dosage (e.g., 500mg twice daily)")

        submit = st.form_submit_button("📝 Generate Prescription")

    if submit:
        if not diagnosis.strip() or not medication.strip():
            st.warning("⚠️ Please fill all required fields (Diagnosis and Medication).")
            return

        user_id = st.session_state.get("user", {}).get("id", "offline_user")

        # Save to text file
        save_prescription_to_txt(user_id, diagnosis.strip(), medication.strip(), dosage.strip())

        st.success("✅ Prescription saved locally!")

    st.markdown("---")
    st.markdown("<h3>Saved Prescriptions (Local Text File)</h3>", unsafe_allow_html=True)

    saved_prescriptions = load_prescriptions_from_txt()
    if saved_prescriptions:
        for idx, presc in enumerate(saved_prescriptions, 1):
            st.markdown(f"**{idx}.** {presc}")
    else:
        st.info("No saved prescriptions found in local text file.")


if __name__ == "__main__":
    show_prescription()
