import streamlit as st
import socket
from services.ai_models import SymptomChecker  # Your real API class
import os
from datetime import datetime

# File to save symptom checks
SYMPTOM_CHECKS_FILE = "symptom_checks.txt"

# --- Connection Check Function ---
def is_connected():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True
    except OSError:
        return False

# --- Offline mock symptom analysis data ---
MOCK_SYMPTOM_ANALYSIS = {
    "fever, headache": {
        "risk_level": "Medium",
        "recommendation": "Consult a doctor within 48 hours."
    },
    "fatigue, cough": {
        "risk_level": "Low",
        "recommendation": "Get plenty of rest and maintain a healthy diet."
    },
    "chest pain, shortness of breath": {
        "risk_level": "High",
        "recommendation": "Seek emergency care immediately!"
    }
}

def run_online_analysis(symptoms_list):
    checker = SymptomChecker()
    try:
        return checker.predict_risk(symptoms_list)
    except Exception as e:
        st.error(f"⚠️ API Error: {e}")
        return None

# Save symptom check result to text file
def save_symptom_check(symptoms_text, risk_level, recommendation):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    record = (
        f"[{timestamp}] Symptoms: {symptoms_text} | "
        f"Risk Level: {risk_level} | Recommendation: {recommendation}\n"
    )
    with open(SYMPTOM_CHECKS_FILE, "a", encoding="utf-8") as f:
        f.write(record)

# Load all saved symptom checks
def load_saved_checks():
    if not os.path.exists(SYMPTOM_CHECKS_FILE):
        return []
    with open(SYMPTOM_CHECKS_FILE, "r", encoding="utf-8") as f:
        return f.readlines()

def show_symptom_checker():
    # --- Custom Styles ---
    st.markdown("""
        <style>
            body {
                background: linear-gradient(to right, #FDFBFB, #EBEDEE);
            }
            .main-container {
                background-color: #ffffff;
                padding: 40px;
                border-radius: 15px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                max-width: 900px;
                margin: auto;
            }
            div[role="radiogroup"] > label {
                background: #D6EAF8;
                color: #154360;
                padding: 10px 20px;
                margin-right: 10px;
                border-radius: 999px;
                font-weight: bold;
                cursor: pointer;
                border: 2px solid transparent;
                transition: all 0.3s ease;
            }
            div[role="radiogroup"] > label:hover {
                background: #AED6F1;
            }
            div[role="radiogroup"] > label[data-selected="true"] {
                background: #3498DB !important;
                color: white !important;
                border: 2px solid #21618C;
            }
            div.stButton > button {
                background-color: #3498DB;
                color: white;
                font-size: 18px;
                padding: 10px 25px;
                border-radius: 10px;
                font-weight: bold;
            }
            div.stButton > button:hover {
                background-color: #21618C;
            }
            textarea {
                background-color: #FDFEFE !important;
                border: 2px solid #00ACC1 !important;
                border-radius: 12px !important;
                box-shadow: 0 2px 6px rgba(0, 172, 193, 0.2) !important;
                font-size: 16px !important;
                color: #154360 !important;
            }
        </style>
    """, unsafe_allow_html=True)

    with st.container():
        
        st.markdown("""
            <div style="background-color: #2C3E50;padding:20px;border-radius:10px;margin-bottom:20px;">
                <h2 style="color:#00ACC1;">🩺 Symptom Checker</h2>
                <p style="font-size:16px;color:#00ACC1;">Analyze your symptoms to assess health risks using AI (online) or mock data (offline).</p>
            </div>
        """, unsafe_allow_html=True)

        # Tip Box
        st.markdown("""
            <div style="background:#E8F8F5;padding:15px;border-radius:10px;margin-bottom:10px;">
                💡 <b>Tip:</b> Enter symptoms separated by commas (e.g., <i>fever, cough, headache</i>)
            </div>
        """, unsafe_allow_html=True)

        # --- Pill-Shaped Mode Selector ---
        mode = st.radio("",
            options=["🌐 Online (Real API)", "💾 Offline (Mock Data)"],
            horizontal=True,
            index=0,
            label_visibility="collapsed"
        )

        if mode == "🌐 Online (Real API)":
            if not is_connected():
                st.error("❌ No internet connection detected. Please switch to Offline mode.")
                st.markdown("</div>", unsafe_allow_html=True)
                return

            # --- Eye-catching Symptom Input Box ---
            st.markdown("""
                <div style="background-color: #2C3E50;padding:20px;border-radius:12px;margin-top:10px;margin-bottom:10px;">
                    <h4 style="color:#00ACC1;margin-bottom:10px;">📝 Enter your symptoms:</h4>
            """, unsafe_allow_html=True)

            symptoms = st.text_area(label="", placeholder="e.g. fever, cough, headache")

            st.markdown("""
                <div style="display: flex; justify-content: center; margin-top: 0px;margin-bottom:10px;">
            """, unsafe_allow_html=True)

            if st.button("🧪 Analyze Symptoms"):
                if symptoms.strip():
                    symptoms_list = [s.strip() for s in symptoms.split(",") if s.strip()]
                    result = run_online_analysis(symptoms_list)
                    if result:
                        st.subheader("🧾 Analysis Result")
                        st.write(f"**Risk Level**: 🚩 {result['risk_level']}")
                        st.write(f"**Recommendation**: {result['recommendation']}")

                        # Save to text file
                        save_symptom_check(symptoms, result['risk_level'], result['recommendation'])

                        if result["risk_level"] == "High":
                            st.error("🚨 Seek emergency care immediately!")
                        elif result["risk_level"] == "Medium":
                            st.warning("🩺 Schedule a doctor's appointment soon.")
                        else:
                            st.success("💚 Monitor symptoms and rest.")
                    else:
                        st.error("Failed to analyze symptoms via API.")
                else:
                    st.warning("⚠️ Please enter symptoms to analyze.")

        else:
            st.info("💾 Offline Mode: Select a predefined symptom set to see analysis.")
            options = list(MOCK_SYMPTOM_ANALYSIS.keys())
            selected_mock = st.selectbox("🧾 Choose a symptom set:", ["-- Select --"] + options)

            if selected_mock != "-- Select --":
                analysis = MOCK_SYMPTOM_ANALYSIS[selected_mock]
                st.subheader("🧾 Analysis Result")
                st.write(f"**Risk Level**: 🚩 {analysis['risk_level']}")
                st.write(f"**Recommendation**: {analysis['recommendation']}")

                # Save to text file
                save_symptom_check(selected_mock, analysis['risk_level'], analysis['recommendation'])

                if analysis["risk_level"] == "High":
                    st.error("🚨 Seek emergency care immediately!")
                elif analysis["risk_level"] == "Medium":
                    st.warning("🩺 Schedule a doctor's appointment soon.")
                else:
                    st.success("💚 Monitor symptoms and rest.")
            else:
                st.markdown("<div style='color: gray;'>⏳ Please select a symptom set to view analysis...</div>", unsafe_allow_html=True)

        st.markdown('</div>', unsafe_allow_html=True)

        # --- Display saved symptom checks from text file ---
        st.markdown("---")
        st.markdown("<h3>📂 Previous Symptom Checks (Saved Locally)</h3>", unsafe_allow_html=True)
        saved_checks = load_saved_checks()
        if saved_checks:
            for idx, check in enumerate(saved_checks[-20:], 1):  # show last 20 only
                st.markdown(f"{idx}. {check}")
        else:
            st.info("No saved symptom checks found locally.")

if __name__ == "__main__":
    show_symptom_checker()
