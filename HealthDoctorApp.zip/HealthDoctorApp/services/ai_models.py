# services/ai_models.py
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from joblib import dump, load
import os

class SymptomChecker:
    def __init__(self):
        self.SYMPTOM_INDEX = {
            'fever': 0, 'cough': 1, 'headache': 2, 'fatigue': 3,
            'nausea': 4, 'dizziness': 5, 'chest_pain': 6, 'shortness_of_breath': 7
        }
        self.model = self._load_model()

    def _load_model(self):
        if os.path.exists("models/symptom_model.joblib"):
            return load("models/symptom_model.joblib")
        else:
            return self._train_demo_model()

    def _train_demo_model(self):
        # Synthetic training data
        X = np.random.rand(200, len(self.SYMPTOM_INDEX))
        y = np.random.choice([0, 1, 2], size=200, p=[0.6, 0.3, 0.1])  # 60% Low, 30% Medium, 10% High
        model = RandomForestClassifier()
        model.fit(X, y)
        os.makedirs("models", exist_ok=True)
        dump(model, "models/symptom_model.joblib")
        return model

    def predict_risk(self, symptoms):
        input_vec = np.zeros(len(self.SYMPTOM_INDEX))
        for symptom in symptoms:
            if symptom.lower() in self.SYMPTOM_INDEX:
                input_vec[self.SYMPTOM_INDEX[symptom.lower()]] = 1
        
        proba = self.model.predict_proba([input_vec])[0]
        risk_level = ["Low", "Medium", "High"][np.argmax(proba)]
        
        return {
            "risk_level": risk_level,
            "confidence": f"{max(proba)*100:.1f}%",
            "recommendation": self._get_recommendation(risk_level)
        }

    def _get_recommendation(self, risk_level):
        return {
            "Low": "Rest and monitor symptoms. Drink plenty of fluids.",
            "Medium": "Consult a doctor within 48 hours.",
            "High": "Seek emergency care immediately!"
        }[risk_level]