import requests
import logging

def fetch_api(endpoint: str) -> dict:
    """Fetch data from a real public API for demo and analysis"""
    base_url = "https://disease.sh/v3"

    endpoints = {
        "global": f"{base_url}/covid-19/all",
        "pakistan": f"{base_url}/covid-19/countries/pakistan",
        "india": f"{base_url}/covid-19/countries/india",
        "usa": f"{base_url}/covid-19/countries/usa",
        "vaccines": f"{base_url}/covid-19/vaccine/coverage/countries"
    }

    url = endpoints.get(endpoint.lower())
    if not url:
        return {"error": f"Unknown endpoint '{endpoint}'"}

    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        logging.error(f"API Error: {str(e)}")
        return {"error": "API call failed. Please check your internet connection or try again later."}

def get_mock_api_data(endpoint: str) -> dict:
    if endpoint == "hospital":
        return {
            "hospital_name": "Baymax General Hospital",
            "location": "Faisalabad, Pakistan",
            "status": "Online & Ready (Mock)",
            "patients_today": 132,
            "doctors_on_duty": 8
        }
    else:
        return {"error": "No mock data available for this endpoint."}
