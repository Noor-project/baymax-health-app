from logic.database import get_db

def get_doctors():
    with get_db() as conn:
        cursor = conn.execute("SELECT id, username FROM users WHERE role = 'doctor'")
        doctors = cursor.fetchall()
    return doctors

def book_appointment(patient_id, doctor_id, date, time_slot):
    with get_db() as conn:
        conn.execute(
            """INSERT INTO appointments (patient_id, doctor_id, date, time_slot) 
               VALUES (?, ?, ?, ?)""",
            (patient_id, doctor_id, date, time_slot)
        )
        conn.commit()

def get_appointments_summary():
    """Return count of appointments per doctor for visualization."""
    with get_db() as conn:
        cursor = conn.execute(
            """SELECT u.username, COUNT(a.id) as appointment_count
               FROM appointments a
               JOIN users u ON a.doctor_id = u.id
               GROUP BY a.doctor_id"""
        )
        data = cursor.fetchall()
    return data
