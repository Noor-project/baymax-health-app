#!/bin/bash

# Initialize
echo "🚀 Deploying Baymax Health App..."
mkdir -p logs
touch logs/app.log

# Validate environment
if [ ! -f ".env" ]; then
    echo "ERROR: Missing .env file"
    exit 1
fi

# Build Docker image
docker build -t baymax-health .

# Run container
docker run -d \
    --name baymax-app \
    -p 8501:8501 \
    --env-file .env \
    -v ./logs:/app/logs \
    baymax-health

# Verify deployment
sleep 5
curl -s http://localhost:8501/_stcore/health | grep "OK" && \
    echo "✅ Deployment successful! Access at http://localhost:8501" || \
    echo "❌ Deployment failed - check logs"