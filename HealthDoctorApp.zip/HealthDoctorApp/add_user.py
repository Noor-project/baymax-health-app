from logic.auth import register_user
from logic.database import init_db
import sys

def main():
    if len(sys.argv) != 4:
        print("Usage: python add_user.py <username> <password> <role>")
        print("Roles: 'doctor' or 'patient'")
        sys.exit(1)

    username, password, role = sys.argv[1], sys.argv[2], sys.argv[3].lower()

    if role not in ['doctor', 'patient']:
        print("Error: Role must be 'doctor' or 'patient'")
        sys.exit(1)

    init_db()
    if register_user(username, password, role):
        print(f"User '{username}' created successfully as {role}")
    else:
        print(f"Failed to create user '{username}'")

if __name__ == "__main__":
    main()
#python add_user.py doctor doctor doctor
#python add_user.py patient patient patient