# tests/test_api_connector.py
import pytest
from unittest.mock import patch
from services.api_connector import HealthAPIClient

@patch('requests.Session.get')
def test_successful_api_call(mock_get):
    mock_get.return_value.status_code = 200
    mock_get.return_value.json.return_value = {"patient_id": 123}
    
    client = HealthAPIClient()
    assert client.get_patient_data(123) == {"patient_id": 123}

@patch('requests.Session.get')
def test_api_failure(mock_get):
    mock_get.return_value.status_code = 500
    client = HealthAPIClient()
    result = client.get_patient_data(123)
    assert "patient_id" in result  # Falls back to mock data