from logic.auth import login, hash_password
from logic.database import get_db
def test_credentials(username, password):
    print(f"\nTesting login for {username}:")
    result = login(username, password)
    print(f"Login result: {result}")
    
    # Show hash comparison
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT password_hash FROM users WHERE username = ?", (username,))
        db_hash = cursor.fetchone()
        if db_hash:
            db_hash = db_hash[0]
            print(f"DB hash: {db_hash.hex()}")
            print(f"New hash: {hash_password(password).hex()}")
            print("Match?" , hash_password(password) == db_hash)

if __name__ == "__main__":
    test_credentials("doctor", "doctor")
    test_credentials("patient", "patient")