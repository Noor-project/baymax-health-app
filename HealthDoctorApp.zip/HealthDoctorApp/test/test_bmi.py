# tests/test_bmi.py
import pytest
from features.bmi_calculator import calculate_bmi

@pytest.mark.parametrize("weight,height,expected", [
    (70, 175, 22.86),    # Normal
    (50, 160, 19.53),    # Underweight
    (90, 180, 27.78),    # Overweight
    (45.5, 152.4, 19.6)  # Decimal values
])
def test_bmi_calculation(weight, height, expected):
    assert calculate_bmi(weight, height) == pytest.approx(expected, 0.1)

def test_zero_height():
    with pytest.raises(ValueError):
        calculate_bmi(70, 0)

def test_negative_values():
    with pytest.raises(ValueError):
        calculate_bmi(-50, 160)