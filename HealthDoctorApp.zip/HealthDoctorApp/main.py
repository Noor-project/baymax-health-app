import streamlit as st
from ui.app_header import show_header
from ui.sidebar import show_sidebar
from ui.app_footer import show_footer
from logic.database import init_db
from logic.auth import login
import importlib

# Initialize DB
init_db()

# Page config
st.set_page_config(
    page_title="Baymax Health",
    page_icon="🏥",
    layout="wide"
)

def load_page(module_path, func_name):
    """Dynamically import pages to avoid hardcoding"""
    try:
        module = importlib.import_module(module_path)
        return getattr(module, func_name)
    except Exception as e:
        st.error(f"Error loading {module_path}.{func_name}: {str(e)}")

# About Page
def show_about_page():
    st.markdown("""
        <div style="background-color:rgb(255,182,193);padding:30px;border-radius:10px;">
            <h2 style="color:#2C3E50;">📖 About </h2> <h1><span style="color:#27AE60;">Baymax Health Companion</span></h1>
            <p style="font-size:20px;color:#2C3E50">
                <b>Baymax Health Companion</b> is your friendly AI-powered virtual healthcare assistant designed to:
            </p>
            <ul style="font-size:20px;color:#333333">
                <li>✅ Empower users with tools for <b>self-diagnosis</b>.</li>
                <li>✅ Provide <b>personalized health tips</b> for well-being.</li>
                <li>✅ Connect patients with hospitals and <b>real doctors</b>.</li>
                <li>✅ Offer features like <b>Symptom Checker, Risk Estimator, Digital Prescriptions</b>.</li>
            </ul>
            <h3 style="color:rgb(161,67,68);font-weight: bold;">🛠️ Technologies Used:</h3>
            <p style="font-size:20px;color:#000000">
                🧠 Machine Learning (AI)<br>
                💻 Python + Streamlit<br>
                📡 API Integration<br>
                🎨 Modern UI/UX with HCI principles
            </p>
            <p style="font-size:22px;color:#4B0082;font-weight: bold;"><i>Created with respect by  Noor || Minahal || Khadija ||</i></p>
        </div>
    """, unsafe_allow_html=True)


import streamlit as st



def main():
    show_header()

    # ✅ Make sure user is initialized
    if 'user' not in st.session_state:
        st.session_state.user = None

    if not st.session_state.user:
        # Create columns for layout (left for graphics, right for login form)
        col1, col2 = st.columns([1, 1])
        
        with col1:
            # Visual elements on the left
          
         st.markdown("""
    <div style="text-align: center; padding: 20px; background-color: #2C3E50; border-radius: 10px;">
        <h1 style="color: #E0F2F1; font-size: 2.5rem; font-weight: bold;">Welcome to Baymax Health</h1>
        <img src="https://media.istockphoto.com/id/1368151370/photo/user-typing-login-and-password-cyber-security-concept.jpg?s=612x612&w=0&k=20&c=hZ14F6Fa4edYWwg0BduAj0is8gdcORsBBHpQcQbAPKc=" width="500" alt="Baymax Health Logo">
        <p style="font-size: 1.2rem; color: #00ACC1;">
            Your friendly AI-powered healthcare companion
        </p>
    </div>

    <div style="margin-top: 30px; padding: 20px; background-color: #2C3E50; border-radius: 10px;">
        <h3 style="color: #E0F2F1;">🌟 Why Login?</h3>
        <ul style="color: #00ACC1; font-size: 1rem; line-height: 1.6;">
            <li>🔐 Secure access to your health data</li>
            <li>💊 Personalized health recommendations</li>
            <li>📅 Book appointments with doctors</li>
            <li>📊 Track your health metrics</li>
        </ul>
    </div>
""", unsafe_allow_html=True)


        with col2:
            # Login form with enhanced styling
            st.markdown("""
                <div style="background-color: #2C3E50; padding: 30px; border-radius: 15px; 
                    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                    <h2 style="color:#E0F2F1; text-align: center; margin-bottom: 30px;">
                        <span style="color: #00ACC1;">🔒</span> Secure Login
                    </h2>
            """, unsafe_allow_html=True)
            
            # Login form inside the styled container
            username = st.text_input("👤 Username", key="username_input")
            password = st.text_input("🔒 Password", type="password", key="password_input")
            
            st.markdown("""
                <style>
                    .stButton>button {
                        background-color: #2C3E50;
                        color: #00ACC1;
                        border: none;
                        padding: 10px 24px;
                        border-radius: 8px;
                        font-size: 20px;
                        font-weight:bold;
                        transition: all 0.3s;
                        width: 100%;
                    }
                    .stButton>button:hover {
                        background-color: #c0392b;
                        transform: translateY(-2px);
                    }
                </style>
            """, unsafe_allow_html=True)
            
            if st.button("Login", key="login_button"):
                user = login(username, password)
                if user:
                    st.session_state.user = user
                    st.rerun()
                else:
                    st.error("Invalid username or password.")
                    
            st.markdown("""
                <div style="text-align: center; margin-top: 20px; color: #7f8c8d;">
                    <p>Don't have an account? <a href="#" style="color: #e74c3c;">Contact admin</a></p>
                    <p style="font-size: 0.8rem;">Forgot password? <a href="#" style="color: #3498db;">Reset here</a></p>
                </div>
                </div>
            """, unsafe_allow_html=True)
            
            # Add some space at the bottom
            st.markdown("<div style='margin-top: 50px;'></div>", unsafe_allow_html=True)
            
        return

    current_page = show_sidebar()

    page_mapping = {
        "🏠 Home": ("ui.home", "show_home"),
        "📖 About": (__name__, "show_about_page"),
        "📊 BMI Calculator": ("features.bmi_calculator", "show_bmi_calculator"),
        "🔍 Symptom Checker": ("features.symptom_checker", "show_symptom_checker"),
        "📈 BMI Graph": ("features.health_charts", "show_health_charts"),
        "🧬 Disease Risk Estimator": ("features.disease_risk", "show_disease_risk"),
        "🌱 Health Tips": ("features.health_tips", "show_health_tips"),
        "📅 Book Appointment": ("features.appointment", "show_appointment"),
        "💊 Digital Prescriptions": ("features.prescription", "show_prescription"),
        "🌐 API Data Viewer": ("features.api_data_viewer", "show_api_data_viewer"),
        "🏥 Connected Hospital": ("logic.connect_hospital", "show_connected_hospital")
    }

    if current_page in page_mapping:
        page_func = load_page(*page_mapping[current_page])
        if page_func:
            page_func()

    show_footer()

if __name__ == "__main__":
    main()
    #python -m streamlit run main.py
    
