from logic.database import get_db

print("=== Checking Database ===")
with get_db() as conn:
    cursor = conn.cursor()
    
    # Check users
    cursor.execute("SELECT id, username, role FROM users")
    print("\nUsers:")
    for user in cursor.fetchall():
        print(f"ID: {user[0]}, Username: {user[1]}, Role: {user[2]}")
    
    # Check password hashes
    cursor.execute("SELECT username, hex(password_hash) FROM users")
    print("\nPassword Hashes:")
    for user in cursor.fetchall():
        print(f"Username: {user[0]}, Hash: {user[1]}")
        #python check_users.py