# logic/utils.py
from typing import Any, Dict, Optional
import json
import hashlib
from functools import lru_cache
import logging
from datetime import datetime

@lru_cache(maxsize=128)
def generate_id(input_str: str) -> str:
    """Generate consistent hash-based ID"""
    return hashlib.md5(input_str.encode()).hexdigest()[:8]

def validate_email(email: str) -> bool:
    """RFC-compliant email validation"""
    import re
    pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
    return re.match(pattern, email) is not None

async def fetch_async(url: str) -> Optional[Dict[str, Any]]:
    """Async HTTP request with error handling"""
    try:
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                return await response.json()
    except Exception as e:
        logging.error(f"Async fetch failed: {str(e)}")
        return None

def log_activity(action: str, metadata: Dict[str, Any] = None) -> None:
    """Audit logging for security compliance"""
    from logic.database import get_db
    try:
        with get_db() as conn:
            conn.execute(
                """INSERT INTO activity_logs 
                (user_id, action, metadata, timestamp)
                VALUES (?, ?, ?, ?)""",
                (
                    st.session_state.get("user_id"),
                    action,
                    json.dumps(metadata or {}),
                    datetime.now().isoformat()
                )
            )
    except Exception as e:
        logging.error(f"Activity log failed: {str(e)}")