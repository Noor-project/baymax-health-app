import streamlit as st
import pandas as pd
import requests

@st.cache_data(ttl=600)
def fetch_live_hospital_data():
    """Try to get live hospital data from real API."""
    url = "https://your-hospital-api.example.com/status"  # Replace with your real API
    try:
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        data = response.json()
        # Basic sanity check
        if not data or 'hospital_name' not in data:
            raise ValueError("Invalid API data")
        return data
    except Exception:
        return None

def show_connected_hospital():
    st.markdown("<h2 style='color:#FF4444'>🏥 Connected Hospital System</h2>", unsafe_allow_html=True)
    st.image(
        "https://sp-ao.shortpixel.ai/client/to_webp,q_glossy,ret_img,w_500,h_500/https://caremedpc.com/wp-content/uploads/2020/04/Health-professional-team.gif",
        width=400
    )

    # Custom styled button
    button_style = """
    <style>
    .stButton > button {
        background-color: #FF4444;
        color: white;
        font-weight: bold;
        padding: 10px 20px;
        border-radius: 10px;
        border: none;
        transition: background-color 0.3s ease;
    }
    .stButton > button:hover {
        background-color: #cc0000;
        color: #fff;
    }
    </style>
    """
    st.markdown(button_style, unsafe_allow_html=True)

    if st.button("Connect to Hospital API"):
        st.info("Attempting to connect to hospital system... 🔗")
        live_data = fetch_live_hospital_data()

        if live_data:
            st.success("✅ Connected to hospital database (Live API)!")
            hospital_data = live_data
            live = True
        else:
            st.warning("⚠️ Live API unavailable. Showing last known or fallback mock data.")
            # Try to load cached data or fallback mock
            cached_data = st.session_state.get("last_hospital_data")
            if cached_data:
                hospital_data = cached_data
            else:
                hospital_data = {
                    "hospital_name": "City Care Hospital (Mock)",
                    "location": "Downtown, Metropolis",
                    "status": "Active (Mock Data)"
                }
            live = False

        # Save live data to session_state cache if available
        if live:
            st.session_state["last_hospital_data"] = hospital_data

        st.markdown(f"**Hospital:** {hospital_data['hospital_name']}")
        st.markdown(f"**Location:** {hospital_data['location']}")
        st.markdown(f"**Status:** {hospital_data['status']}")

        # Visualization data (can be replaced by live stats if API provides)
        # Here we just simulate or extend mock data
        data = {
            "Departments": ["Cardiology", "Neurology", "Oncology", "Pediatrics", "Orthopedics"],
            "Patients": [120, 85, 45, 150, 60],
            "Staff": [30, 20, 15, 40, 25],
            "Satisfaction %": [88, 92, 85, 90, 87]
        }
        df = pd.DataFrame(data)

        st.markdown("### Patient Statistics and Visualizations 📊")
        st.bar_chart(df.set_index("Departments")["Patients"])
        st.line_chart(df.set_index("Departments")["Staff"])

        def highlight_satisfaction(val):
            if val > 90:
                color = 'background-color: #b6fcb6'  # light green
            elif val > 85:
                color = 'background-color: #fff9a6'  # light yellow
            else:
                color = 'background-color: #fcb6b6'  # light red
            return color

        st.dataframe(df.style.applymap(highlight_satisfaction, subset=["Satisfaction %"]))

if __name__ == "__main__":
    show_connected_hospital()
