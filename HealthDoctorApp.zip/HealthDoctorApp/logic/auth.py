from logic.database import get_db
from datetime import datetime, timedelta
import hashlib
import functools
import streamlit as st  # ✅ required for require_login

def hash_password(password: str) -> bytes:
    salt = b'BaymaxSecureSalt2023!'
    return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)

def register_user(username: str, password: str, role: str) -> bool:
    try:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
            if cursor.fetchone():
                return False  # username exists

            password_hash = hash_password(password)
            cursor.execute(
                "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
                (username, password_hash, role.lower())
            )
            conn.commit()
        return True
    except Exception as e:
        print("Error in register_user:", e)
        return False

def login(username: str, password: str) -> dict:
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id, username, password_hash, role FROM users WHERE username = ?",
            (username,)
        )
        user = cursor.fetchone()
        if user and hash_password(password) == user[2]:
            return {
                'id': user[0],
                'username': user[1],
                'role': user[3],
                'expiry': datetime.now() + timedelta(hours=2)
            }
    return None

# ✅ Add this at the end:
def require_login(func):
    """Decorator to ensure only logged-in users access the page"""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        if "user" not in st.session_state or st.session_state.user is None:
            st.warning("🔐 Please log in to access this feature.")
            return
        return func(*args, **kwargs)
    return wrapper
