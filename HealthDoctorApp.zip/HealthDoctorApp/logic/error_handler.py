# logic/error_handler.py
import logging
import traceback
import streamlit as st
from typing import Type

class AppError(Exception):
    """Base exception class"""
    pass

class DatabaseError(AppError):
    pass

class APIError(AppError):
    pass

def handle_error(error: Exception) -> None:
    """
    Central error handler that:
    1. Logs detailed errors
    2. Shows user-friendly messages
    3. Triggers alerts for critical issues
    """
    error_trace = traceback.format_exc()
    
    # Configure logging
    logging.basicConfig(
        filename='health_app_errors.log',
        level=logging.ERROR,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    logging.error(f"{type(error).__name__}: {str(error)}\n{error_trace}")
    
    # User-facing messages
    error_messages = {
        DatabaseError: "Database operation failed. Our engineers have been notified.",
        APIError: "Service temporarily unavailable. Please try again later.",
        Exception: "An unexpected error occurred. We're working on it!"
    }
    
    st.error(error_messages.get(type(error), error_messages[Exception]))
    
    # Critical error alert (would integrate with Slack/email in production)
    if isinstance(error, (DatabaseError, APIError)):
        send_alert_to_team(error)

def send_alert_to_team(error: Exception) -> None:
    """In production, would connect to PagerDuty/Slack"""
    print(f"ALERT: {type(error).__name__} - {str(error)}")  # Replace with actual integration