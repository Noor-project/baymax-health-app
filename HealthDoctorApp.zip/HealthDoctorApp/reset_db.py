from logic.database import reset_db

if __name__ == "__main__":
    if reset_db():
        print("✅ Database reset successfully")
    else:
        print("❌ Database reset failed")
        #python reset_db.py