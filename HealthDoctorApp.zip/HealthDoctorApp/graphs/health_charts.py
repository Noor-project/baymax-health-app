import streamlit as st
import pandas as pd
import plotly.express as px
from logic.database import get_db
from logic.auth import require_login

@require_login
def show_bmi_graph():
    """Show a clean, readable BMI trend chart with accessible colors"""
    try:
        with get_db() as conn:
            df = pd.read_sql(
                "SELECT date(timestamp) AS date, bmi FROM health_metrics WHERE user_id = ? ORDER BY timestamp",
                conn,
                params=(st.session_state.user['id'],)
            )

        if df.empty:
            st.info("📭 No BMI history available.")
            return

        # Accessible color bands
        bands = [
            {"label": "Underweight", "min": 0, "max": 18.5, "color": "#ADD8E6", "text_color": "#000000"},
            {"label": "Healthy", "min": 18.5, "max": 25, "color": "#90EE90", "text_color": "#000000"},
            {"label": "Overweight", "min": 25, "max": 30, "color": "#FFD700", "text_color": "#000000"},
            {"label": "Obese", "min": 30, "max": 50, "color": "#FF7F7F", "text_color": "#000000"},
        ]

        fig = px.line(
            df, x="date", y="bmi",
            title="<b>📈 Your BMI Trend</b>",
            markers=True,
            line_shape="spline",
            template="plotly_white"
        )

        # Add visual BMI category bands
        for band in bands:
            fig.add_hrect(
                y0=band["min"], y1=band["max"],
                fillcolor=band["color"], opacity=0.3,
                layer="below", line_width=0,
                annotation_text=f"{band['label']}",
                annotation_position="top left",
                annotation=dict(
                    font_size=13,
                    font_color=band["text_color"]
                )
            )

        # Final layout tweaks
        fig.update_traces(
            line=dict(color="#1976D2", width=3),
            marker=dict(size=7),
            hovertemplate="<b>Date:</b> %{x}<br><b>BMI:</b> %{y:.1f}<extra></extra>"
        )

        fig.update_layout(
            xaxis_title="<b>Date</b>",
            yaxis_title="<b>BMI Value</b>",
            hovermode="x unified",
            plot_bgcolor="white",
            paper_bgcolor="white",
            margin=dict(l=30, r=30, t=60, b=30),
            yaxis=dict(gridcolor="lightgray"),
            xaxis=dict(gridcolor="lightgray")
        )

        st.plotly_chart(fig, use_container_width=True)

        # Determine the current BMI category
        latest_bmi = df["bmi"].iloc[-1]
        if latest_bmi < 18.5:
            category = "Underweight"
            color = "#ADD8E6"
        elif 18.5 <= latest_bmi < 25:
            category = "Healthy"
            color = "#90EE90"
        elif 25 <= latest_bmi < 30:
            category = "Overweight"
            color = "#FFD700"
        else:
            category = "Obese"
            color = "#FF7F7F"

        st.markdown(f"""
            <div style="background-color:{color}; padding: 16px; border-radius: 10px; color: black; margin-top: 20px;">
                <h4 style="margin-bottom: 5px;"><b>📌 Latest BMI:</b> {latest_bmi:.1f}</h4>
                <p style="margin: 0; font-size: 16px;">You are in the <b>{category}</b> category.</p>
            </div>
        """, unsafe_allow_html=True)

    except Exception as e:
        st.error(f"❌ Could not load BMI chart: {str(e)}")
