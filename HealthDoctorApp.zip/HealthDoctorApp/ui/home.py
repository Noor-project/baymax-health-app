import streamlit as st
from PIL import Image
import base64
import os

# ===== BACKGROUND SETUP =====
def set_background():
    st.markdown(
        f"""
        <style>
        .stApp {{
            background: linear-gradient(135deg, #e0f2fe 0%, #bae6fd 50%, #7dd3fc 100%);
            background-attachment: fixed;
            background-size: cover;
        }}
        .feature-card {{
            transition: all 0.3s ease;
            cursor: pointer;
            background: white !important;
        }}
        </style>
        """,
        unsafe_allow_html=True
    )

def show_home():
    set_background()  # Apply the background

    # ===== HEADER =====
    st.markdown("""
    <style>
    .main-header {
        color: #075985;
        font-size: 2.8rem;
        text-align: center;
        margin-bottom: 0;
        text-shadow: 1px 1px 2px rgba(255,255,255,0.3);
    }
    .sub-header {
        color: #1e40af;
        text-align: center;
        font-size: 1.2rem;
        margin-top: 0;
    }
    </style>
    <h1 class="main-header">🏥 Baymax Health Companion</h1>
    <p class="sub-header">Your AI-powered 360° health management system</p>
    """, unsafe_allow_html=True)

    # ===== HERO SECTION =====
    with st.container():
        col1, col2 = st.columns([1.2, 1])
        with col1:
            st.markdown("""
            <div style='padding: 1.5rem; border-radius: 15px; background: rgba(255,255,255,0.8);'>
            <h3 style='color: #0369a1;'>🌡️ Your Health Dashboard</h3>
            <p style='color: #4b5563;'>
            Get instant access to 8 powerful health tools designed to give you 
            <span style='color: #075985; font-weight: bold;'>personalized medical insights</span> 
            and <span style='color: #075985; font-weight: bold;'>seamless care coordination</span>.
            </p>
            </div>
            """, unsafe_allow_html=True)
            
            # Quick Access Buttons
            st.markdown("""
            <div style='display: flex; gap: 10px; margin-top: 1rem;'>
            <button style='flex: 1; padding: 10px; border-radius: 8px; background: #38bdf8; color: white; border: none;'>Check Symptoms</button>
            <button style='flex: 1; padding: 10px; border-radius: 8px; background: #0ea5e9; color: white; border: none;'>Calculate BMI</button>
            <button style='flex: 1; padding: 10px; border-radius: 8px; background: #0284c7; color: white; border: none;'>Book Doctor</button>
            </div>
            """, unsafe_allow_html=True)
            
        with col2:
            # Health visualization with white bg
            st.markdown("""
            <div style='background: white; border-radius: 15px; padding: 1.5rem; height: 220px; 
                        display: flex; align-items: center; justify-content: center;
                        box-shadow: 0 4px 6px rgba(0,0,0,0.1);'>
            <div style='text-align: center;'>
            <svg width='80' height='80' viewBox='0 0 24 24' fill='none' stroke='#0369a1'>
            <path d='M12 2v4m0 12v4M4.93 4.93l2.83 2.83m8.48 8.48l2.83 2.83M2 12h4m12 0h4M4.93 19.07l2.83-2.83m8.48-8.48l2.83-2.83'/>
            <circle cx='12' cy='12' r='3'/>
            </svg>
            <h3 style='color: #075985; margin-top: 10px;'>Health Status</h3>
            <p style='color: #4b5563;'>Last checkup: Today</p>
            </div>
            </div>
            """, unsafe_allow_html=True)

    # ===== FEATURE SHOWCASE =====
    st.markdown("""
    <style>
    .feature-title {
        color: #1e40af;
        font-size: 1.4rem;
        margin: 1.5rem 0;
        text-align: center;
        text-shadow: 1px 1px 2px rgba(255,255,255,0.3);
    }
    </style>
    <h2 class='feature-title'>🚀 Explore Your Health Tools</h2>
    """, unsafe_allow_html=True)

    features = [
        {"icon": "⚖️", "title": "BMI Calculator", "desc": "Track your body mass index with smart recommendations", "color": "#38bdf8"},
        {"icon": "🔍", "title": "Symptom Checker", "desc": "AI-powered analysis of your symptoms", "color": "#0ea5e9"},
        {"icon": "⚠️", "title": "Disease Risk", "desc": "Personalized risk assessment for chronic conditions", "color": "#0284c7"},
        {"icon": "💊", "title": "Digital-Prescriptions", "desc": "Digital prescriptions sent directly to pharmacies and this tab is only accessible by doctor", "color": "#0369a1"},
        {"icon": "🏥", "title": "Hospital Network", "desc": "Find and connect with trusted healthcare providers", "color": "#075985"},
        {"icon": "📅", "title": "Appointment Booking", "desc": "Seamless scheduling with doctors", "color": "#0c4a6e"},
        {"icon": "💡", "title": "Health Tips", "desc": "Personalized wellness recommendations", "color": "#500C58"},
        {"icon": "📊", "title": "API Data Viewer", "desc": "Advanced health data visualization", "color": "#5412a0"}
    ]

    cols = st.columns(4)
    for idx, feature in enumerate(features):
        with cols[idx % 4]:
            st.markdown(f"""
            <div class='feature-card' style='
                border-radius: 12px;
                padding: 1.2rem;
                margin-bottom: 1rem;
                border-left: 4px solid {feature["color"]};
                box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            '>
            <div style='display: flex; align-items: center; gap: 10px; margin-bottom: 10px;'>
            <span style='font-size: 1.5rem;'>{feature["icon"]}</span>
            <h3 style='color: {feature["color"]}; margin: 0;'>{feature["title"]}</h3>
            </div>
            <p style='color: #4b5563; font-size: 0.9rem;'>{feature["desc"]}</p>
            </div>
            """, unsafe_allow_html=True)

    # ===== CALL-TO-ACTION =====
    st.markdown("""
    <div style='
        background: rgba(255,255,255,0.9);
        border-radius: 15px;
        padding: 2rem;
        margin-top: 2rem;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    '>
    <div style='display: flex; align-items: center; gap: 2rem;'>
    <div style='flex: 2;'>
    <h2 style='color: #075985;'>Ready to begin?</h2>
    <p style='color: #4b5563;'>Select any feature from the <strong>navigation tab</strong> to get started!</p>
    </div>
    <div style='flex: 1; text-align: center;'>
    <button style='
        padding: 12px 24px;
        background: linear-gradient(135deg, #0ea5e9 0%, #0369a1 100%);
        color: white;
        border: none;
        border-radius: 8px;
        font-weight: bold;
        font-size: 1rem;
    '>Explore Features →</button>
    </div>
    </div>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    show_home()