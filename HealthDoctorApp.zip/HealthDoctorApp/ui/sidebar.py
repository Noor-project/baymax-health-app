import streamlit as st
from typing import Dict, Any
import base64

def show_sidebar() -> str:
    if "dark_mode" not in st.session_state:
        st.session_state.dark_mode = False
    dark_mode = st.sidebar.toggle("🌗 Dark Mode", value=st.session_state.dark_mode)
    st.session_state.dark_mode = dark_mode

    # Theme Colors
    if dark_mode:
        colors = {
            "app_bg": "#0F172A",            # Deep navy (main background – very calming, ideal for dark mode)
    "sidebar_bg": "#1E293B",        # Dark slate blue (differentiates sidebar gently)
    "text_color": "#00ACC1",        # Soft mint-white (calm, not harsh like pure white)
    "border_color": "#334155",      # Cool steel gray (professional & subtle)
    "hover_bg": "#116466",          # Muted teal-green (stands out but soft on hover)
    "accent": "#23F573",            # Bright teal-green (active items – energetic yet calm)
    "shadow": "rgba(23, 255, 209, 0.15)",  # Soft teal glow shadow (subtle depth)
    "card_bg": "#1E3A8A",           # Soft deep blue (card container – readable & calm)
    "card_border": "#0F3460",       # Deeper blue-gray for card border
    "emergency": "#EF4444"                # Red for urgent items
        }
    else:
         colors = {
           "app_bg": "rgb(224, 250, 255)",         # Soft minty light cyan — very calming and clean
    "sidebar_bg": "#BCEDF5",                # Light cyan/teal for sidebar — calm, soft background
    "text_color": "#37474F",                 # Dark slate gray — comfortable and clear readability
    "border_color": "#80DEEA",               # Soft cyan blue for subtle borders
    "hover_bg": "#B2EBF2",                   # Slightly deeper light cyan for hover effects
    "accent": "#4DB6AC",                     # Muted teal-green for buttons/highlights (calm & trustworthy)
    "shadow": "rgba(77, 182, 172, 0.2)",    # Soft teal shadow for subtle depth
    "card_bg": "#FFFFFF",                    # Clean white cards for content
    "card_border": "#B2DFDB",                # Very light teal border for cards
    "emergency": "#D32F2F"                 # Bright red
        }

    st.markdown("""
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    """, unsafe_allow_html=True)

    # Custom CSS Styling
   
    #font-size: 16px !important;  # Change this value to increase menu text size

    st.markdown(f"""
    <style>
    html, body, [class*="stApp"] {{
        background-color: {colors['app_bg']} !important;
        color: {colors['text_color']} !important;
        font-family: 'Poppins', sans-serif !important;
    }}

    /* Sidebar container adjustments */
    section[data-testid="stSidebar"] {{
        top: 0 !important;
        height: 100vh !important;
    }}

    section[data-testid="stSidebar"] > div {{
        background: {colors['sidebar_bg']} !important;
        padding: 2rem 1rem !important;
        border-radius: 0 !important;
        margin: 0 !important;
        box-shadow: 0 4px 20px {colors['shadow']};
        height: 100% !important;
    }}
    

    /* Radio button group adjustments */
    section[data-testid="stSidebar"] .stRadio > div {{
        font-size: 22px !important;  
        display: flex !important;
        flex-direction: column !important;
        gap: 10px !important;
    }}


    section[data-testid="stSidebar"] .stRadio div[role="radiogroup"] > label {{
        background: {colors['hover_bg']};
        border: 2px solid {colors['border_color']};
        padding: 12px 16px !important;
        border-radius: 10px !important;
        margin: 0 !important;
        color: {colors['text_color']} !important;
        font-weight: 800 !important;
        display: flex !important;
        align-items: center !important;
        gap: 10px !important;
        transition: background 0.3s ease !important;
        cursor: pointer !important;
    }}

    section[data-testid="stSidebar"] .stRadio div[role="radiogroup"] > label:hover {{
        background: {colors['accent']} !important;
        color: white !important;
    }}

    section[data-testid="stSidebar"] .stRadio div[role="radiogroup"] > label:has(input:checked) {{
        background-color: {colors['accent']} !important;
        color: white !important;
        font-weight: 900 !important;
        box-shadow: 0 4px 10px {colors['shadow']} !important;
    }}

    section[data-testid="stSidebar"] input[type="radio"] {{
        display: none !important;
    }}

    /* Adjust the toggle position */
    section[data-testid="stSidebar"] .stToggle {{
        margin-bottom: 2.5rem !important;
    }}
    </style>
    """, unsafe_allow_html=True)

    user = st.session_state.get("user", {})
    role = user.get("role", "patient")
    sidebar_title = """
    <h1 style='color: #3B82F6;font-weight: bold;'>🧭 Navigation</h1>
"""
    st.sidebar.markdown(sidebar_title, unsafe_allow_html=True)

# Then add the logged-in user role info:
    st.sidebar.markdown("<span style='color: #10B981; font-weight: bold;'>👤 Logged in as: *Patient" if role == "patient" else "👤 Logged in as: **Doctor*", unsafe_allow_html=True)

    pages = [
        "🏠 Home",
        "📖 About",
        "📊 BMI Calculator",
        "🔍 Symptom Checker",
        "🧬 Disease Risk Estimator",
        "🌱 Health Tips",
        "🌐 API Data Viewer",
        "🏥 Connected Hospital"

    ]

    if role == "doctor":
        pages.append("💊 Digital Prescriptions")
    else:
        pages.append("📅 Book Appointment")
       
    
    return st.sidebar.radio("Menu", pages)

def main():
    selected_page = show_sidebar() 
    
    # Get current theme colors
    dark_mode = st.session_state.get("dark_mode", False)
    theme_colors = {
        "primary": "#420394" if dark_mode else "#0F73B6",
        "text": "#12CCC3" if dark_mode else "#12CCC3"   ,
        "card_bg": "#B80E0E" if dark_mode else "#dd1721",
        "border": "#DF0E0E" if dark_mode else "#b30ef5"
    }

    # ===== CUSTOM STYLES =====
    st.markdown(f"""
    <style>
    /* Header Styles */
    .main-title {{
        color: {theme_colors['primary']} !important;
        font-size: 3.8rem !important;
        text-align: center;
        margin-bottom: 1rem;
        font-weight: 800;
    }}
    .sub-title {{
        color: {theme_colors['text']} !important;
        text-align: center;
        font-size: 2rem;
        margin-bottom: 2.5rem;
    }}

    /* Card Styles */
    .feature-card {{
        background: {theme_colors['card_bg']} !important;
        border-radius: 14px !important;
        padding: 1.50rem !important;
        margin-bottom: 1rem !important;
        border-left: 5px solid;
        box-shadow: 0 3px 10px rgba(0,0,0,0.08) !important;
        transition: transform 0.3s ease, box-shadow 0.3s ease !important;
        color: {theme_colors['text']} !important;
    }}
    .feature-card:hover {{
        transform: translateY(-3px) !important;
        box-shadow: 0 6px 15px rgba(0,0,0,0.12) !important;
    }}

    /* Button Styles */
    .custom-btn {{
        border: none !important;
        border-radius: 8px !important;
        font-weight: 500 !important;
        transition: all 0.3s ease !important;
        background: linear-gradient(135deg, #0ea5e9 0%, #0369a1 100%) !important;
        color: white !important;
    }}
    .custom-btn:hover {{
        transform: translateY(-2px) !important;
        box-shadow: 0 4px 8px rgba(7, 89, 133, 0.3) !important;
    }}

    /* Container Styles */
    .hero-container {{
        background: rgba(255,255,255,{0.15 if dark_mode else 0.85}) !important;
        border-radius: 15px !important;
        padding: 1.5rem !important;
        margin-bottom: 1.5rem !important;
        color: {theme_colors['text']} !important;
    }}
    .cta-container {{
        background: rgba(255,255,255,{0.2 if dark_mode else 0.9}) !important;
        border-radius: 15px !important;
        padding: 2rem !important;
        margin-top: 2rem !important;
    }}
    </style>
    """, unsafe_allow_html=True)

    # ===== HEADER SECTION =====
    st.markdown('<h1 class="main-title">🏥 Baymax Health Companion</h1>', unsafe_allow_html=True)
    st.markdown(f'<p class="sub-title">AI-Powered Healthcare at Your Fingertips</p>', unsafe_allow_html=True)

    # ===== HERO SECTION =====
    with st.container():
        col1, col2 = st.columns([1.2, 1])
        with col1:
            st.markdown(f"""
            <div class="hero-container">
            <h3 style='color: {theme_colors['primary']}; margin-top: 0;'>🌡 Your Personal Health Hub</h3>
            <p style='color: {theme_colors['text']};'>
            Access <strong>8 specialized tools</strong> for complete health management - 
            from symptom analysis to hospital connections, all in one secure platform.
            </p>
            <div style='display: flex; gap: 10px; margin-top: 1.5rem;'>
                <button class="custom-btn" style='flex: 1; padding: 10px;'>Check Symptoms</button>
                <button class="custom-btn" style='flex: 1; padding: 10px;'>Calculate BMI</button>
            </div>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.markdown(f"""
            <div style='background: {theme_colors['card_bg']}; border-radius: 15px; padding: 1.5rem; height: 100%; 
                        display: flex; flex-direction: column; justify-content: center;
                        box-shadow: 0 4px 6px rgba(0,0,0,0.05);'>
            <div style='text-align: center;'>
                <svg width='70' height='70' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
                    <path d='M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z' stroke='{theme_colors['primary']}' stroke-width='2'/>
                    <path d='M8 14C8 14 9.5 16 12 16C14.5 16 16 14 16 14M9 9H9.01M15 9H15.01' stroke='{theme_colors['primary']}' stroke-width='2' stroke-linecap='round'/>
                </svg>
                <h3 style='color: {theme_colors['primary']}; margin: 15px 0 5px 0;'>Your Health Status</h3>
                <p style='color: {theme_colors['text']}; margin: 0; font-size: 0.9rem;'>Last updated: Today</p>
            </div>
            </div>
            """, unsafe_allow_html=True)

    # ===== FEATURE SHOWCASE =====
    st.markdown(f"""
    <h2 style='color: {theme_colors['primary']}; text-align: center; margin: 2rem 0 1rem 0;'>
        ✨ Key Health Features
    </h2>
    """, unsafe_allow_html=True)

    features = [
        {"icon": "⚖", "title": "BMI Calculator", "desc": "Calculate and track your body mass index with personalized health insights", "color": "#0ea5e9"},
        {"icon": "🔍", "title": "Symptom Checker", "desc": "AI-driven analysis of your symptoms with probable condition matches", "color": "#38bdf8"},
        {"icon": "⚠", "title": "Disease Risk", "desc": "Personalized assessment of chronic disease risks based on your profile", "color": "#0284c7"},
        {"icon": "💊", "title": "e-Prescriptions", "desc": "Digital prescriptions sent directly to your preferred pharmacy", "color": "#0369a1"},
        {"icon": "🏥", "title": "Hospital Network", "desc": "Find and connect with certified healthcare providers near you", "color": "#075985"},
        {"icon": "📅", "title": "Book Appointments", "desc": "Seamless scheduling with doctors and specialists", "color": "#0c4a6e"},
        {"icon": "💡", "title": "Health Tips", "desc": "Daily personalized wellness recommendations", "color": "#7dd3fc"},
        {"icon": "📊", "title": "API Data", "desc": "Advanced visualization of your health metrics", "color": "#bae6fd"}
    ]

    cols = st.columns(4)
    for idx, feature in enumerate(features):
        with cols[idx % 4]:
            st.markdown(f"""
            <div class='feature-card' style='border-left-color: {feature["color"]}'>
                <div style='display: flex; align-items: center; gap: 10px; margin-bottom: 12px;'>
                    <span style='font-size: 1.4rem;'>{feature["icon"]}</span>
                    <h3 style='color: {feature["color"]}; margin: 0; font-size: 1.1rem;'>{feature["title"]}</h3>
                </div>
                <p style='color: {theme_colors['text']}; margin: 0; font-size: 0.85rem; line-height: 1.4;'>
                    {feature["desc"]}
                </p>
            </div>
            """, unsafe_allow_html=True)

    # ===== CALL-TO-ACTION =====
    st.markdown(f"""
    <div class="cta-container">
        <div style='display: flex; align-items: center;'>
            <div style='flex: 2;'>
                <h2 style='color: {theme_colors['primary']}; margin-top: 0;'>Ready to Begin?</h2>
                <p style='color: {theme_colors['text']}; margin-bottom: 0;'>
                    Select any feature from the navigation menu to start your health journey!
                </p>
            </div>
            <div style='flex: 1; text-align: center;'>
                <button class="custom-btn" style='padding: 12px 24px; margin-left: auto;'>
                    Explore Features →
                </button>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "_main_":
    main()