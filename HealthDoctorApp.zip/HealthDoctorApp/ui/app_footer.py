import streamlit as st

def show_footer():
    st.markdown("""
        <style>
            .footer {
                background: linear-gradient(90deg, #0066cc 0%, #004d99 100%);
                padding: 1rem;
                color: white;
                border-radius: 15px 15px 0 0;
                margin-top: 2rem;
                text-align: center;
            }
                .footer p {
    margin: 5px;
    font-size: 18px;
    color: #23F573;
     }
            .social-icons a {
                color: white !important;
                margin: 0 10px;
                font-size: 2rem;
            }
      </style>

<div class="footer">
    <div class="social-icons">
        <a href="https://twitter.com" target="_blank">🐦</a>
        <a href="https://github.com" target="_blank">💻</a>
        <a href="mailto:contact@baymax.com">✉️</a>
    </div>
    <p>© 2025 <strong>Baymax Health</strong> | <em>Designed by Team Noor, Minahal, Khadija</em> | <strong>HCI & Graphics</strong></p>
</div>
""", unsafe_allow_html=True)