import streamlit as st
from datetime import datetime

def show_header():
    """Render app header with doctor icon and health graphics"""
    user = st.session_state.get("user", None)
    username = user["username"] if user else "Guest"
    role = user["role"] if user else ""

    st.markdown(f"""
        <style>
            .header {{
                background:linear-gradient(135deg, #00B4D8, #0077B6);
                padding: 1.5rem;
                color: rgb(255,245,254);
                border-radius: 0 0 15px 15px;
                margin-bottom: 2rem;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                font-family: 'Arial', sans-serif;
                position: relative;
                overflow: hidden;
            }}
            .header::before {{
                content: "⚕";
                position: absolute;
                font-size: 9rem;
                opacity: 0.05;
                right: 20px;
                top: -20px;
                z-index: 0;
            }}
            .user-status {{
                float: right;
                font-size: 0.9rem;
                margin-top: -10px;
                background: rgba(255,255,255,0.15);
                padding: 6px 12px;
                border-radius: 20px;
                backdrop-filter: blur(5px);
                position: relative;
                z-index: 1;
            }}
            .header h1 {{
                margin-bottom: 0;
                display: flex;
                align-items: center;
                gap: 10px;
                position: relative;
                z-index: 1;
            }}
            .st-emotion-cache-1q7spjk {{
                background: #F0F9FF !important;
                border: 1px solid #D1E9FF !important;
            }}
            .pulse {{
                animation: pulse 3s infinite;
            }}
            @keyframes pulse {{
                0% {{ transform: scale(1); }}
                50% {{ transform: scale(1.05); }}
                100% {{ transform: scale(1); }}
            }}
        </style>
        <div class="header pulse">
            <h1>
                <span style="font-size:1.5em">👨‍⚕️🏥</span>  <!-- Female doctor icon (use 👨‍⚕️🏥 for male) -->
                <span>Baymax Health Portal</span>
            </h1>
            <div class="user-status">
                👤 {username} <span style="opacity:0.8">({role})</span> | 📅 {datetime.now().strftime('%d %b %Y')}
            </div>
        </div>
    """, unsafe_allow_html=True)

    # System status with health metrics
    with st.expander("🏥 Health System Dashboard", expanded=False,):
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Active Users", "1,024", "12% ↑")
        with col2:
            st.metric("Appointments", "78", "3 today")
        with col3:
            st.metric("Response Time", "0.2s", "99.9% uptime")
        
        st.progress(0.9, text="Server load: 90% (Optimal)")
        st.caption(f"Last updated: {datetime.now().strftime('%H:%M:%S')} | 🔒 HIPAA-compliant")

# Test the component
if __name__ == "__main__":
    st.session_state.user = {"username": "Dr. Smith", "role": "Physician"}
    show_header()
    st.success("✨ New features added! Try our **symptom checker** in the sidebar.")